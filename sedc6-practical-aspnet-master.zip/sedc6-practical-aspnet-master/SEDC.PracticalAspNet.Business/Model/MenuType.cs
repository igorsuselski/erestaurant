﻿namespace SEDC.PracticalAspNet.Business.Model
{
    public enum MenuType : byte
    {
        Undefined = 0,

        Meals = 1,

        Drinks = 2,

        Wines = 3
    }
}